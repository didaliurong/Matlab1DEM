%input*************model description  *******************
%the 1D reservoir model
bc1=[1d-12,   3.3           1       0.01          1];%conductivity of each layers(from top to deepest);
h1=[1d60,    1000        1000        100       1d60];%thickness of each layer
z1=[      0       1000         2000      2100      ];%interface
%the background model
bc2=[1d-12,   3.3            1];
h2=[1d60,    1000         1d60];
z2=[      0         1000      ];
%design the Tx-Rx
TX=[0,0,950];                                                %position of the transmitter
T0=2;                                                        % the transmitter is the 2th layer
[Tmodel01,TmodelM1,TmodelN1]=select_model(T0,bc1,h1,z1);% Rearrange the order of layers for background model
[Tmodel02,TmodelM2,TmodelN2]=select_model(T0,bc2,h2,z2);% Rearrange the order of layers for 1D reservoir model
f=1;                               %frequency of the transmitter
%positions of the receivers
RX=100:200:8100;
%receivers above 0.1m the seafloor
PS_up=zeros(length(RX),3);PS_up(:,1)=RX;PS_up(:,3)=999.9;
%receivers beneath 0.1m the seafloor
PS_down=zeros(length(RX),3); PS_down(:,1)=RX;PS_down(:,3)=1000.1;

%for receivers above the seafloor 
[ XEx,XEy,XEz ]=E_XED(PS_up,TX,Tmodel01,TmodelM1,TmodelN1,f);%on the background model
Ex_up1=XEx;
Ez_up1=XEz;
[ XEx,XEy,XEz ]=E_XED(PS_up,TX,Tmodel02,TmodelM2,TmodelN2,f);%on the 1D reservoir model 
Ex_up2=XEx;
Ez_up2=XEz;

%for receivers beneath the seafloor 
[ XEx,XEy,XEz ]=E_XED(PS_down,TX,Tmodel01,TmodelM1,TmodelN1,f);%return the electric fields by x-directed electric source on the background model
Ex_down1=XEx;
Ez_down1=XEz;
[ XEx,XEy,XEz ]=E_XED(PS_down,TX,Tmodel02,TmodelM2,TmodelN2,f);%return the electric fields by x-directed electric source on the 1D reservoir model 
Ex_down2=XEx;
Ez_down2=XEz;

%output the results
filename1=strcat(num2str(f),'Hz','marine 1D analysis solution.txt');
fid1=fopen(filename1,'wt');
for i=1:length(RX)
    fprintf(fid1,'%12.5g\t',RX(i));  
    fprintf(fid1,'%12.5g\t',real(Ex_up2(i)));
    fprintf(fid1,'%12.5g\t',imag(Ex_up2(i)));
    fprintf(fid1,'%12.5g\t',real(Ex_up1(i)));
    fprintf(fid1,'%12.5g\t',imag(Ex_up1(i)));
    
    fprintf(fid1,'%12.5g\t',real(Ex_down2(i)));
    fprintf(fid1,'%12.5g\t',imag(Ex_down2(i)));
    fprintf(fid1,'%12.5g\t',real(Ex_down1(i)));
    fprintf(fid1,'%12.5g\t',imag(Ex_down1(i)));
    
    fprintf(fid1,'%12.5g\t',real(Ez_up2(i)));
    fprintf(fid1,'%12.5g\t',imag(Ez_up2(i)));
    fprintf(fid1,'%12.5g\t',real(Ez_up1(i)));
    fprintf(fid1,'%12.5g\t',imag(Ez_up1(i)));
    
    fprintf(fid1,'%12.5g\t',real(Ez_down2(i)));
    fprintf(fid1,'%12.5g\t',imag(Ez_down2(i)));
    fprintf(fid1,'%12.5g\t',real(Ez_down1(i)));
    fprintf(fid1,'%12.5g\n',imag(Ez_down1(i)));    
end


 