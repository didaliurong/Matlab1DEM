
%reid validation
tic
 Reid_validationXMD;
 toc
clear
tic
 Reid_validationZMD;
 toc
clear

%example
tic
 example_XED_Vector;
 toc
clear
tic
 example_ZED_Vector;
 toc
clear
tic
 example_XMD_Vector;
 toc
clear
tic
example_ZMD_Vector;
toc
clear

%application marine CSEM
tic
 marineCSEM_Analysis;
 toc
clear
tic
 marineCSEM_Current;
 toc
clear

%application AEM
tic
 AEM_CurrentXMD;
 toc
clear
tic
 AEM_CurrentZMD;
 toc
clear
