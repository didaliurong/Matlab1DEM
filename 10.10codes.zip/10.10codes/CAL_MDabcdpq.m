function [C0MM,C0NN,CMM,CNN] = CAL_MDabcdpq(L,model0,modelM,modelN,zR,zT,w)

J=sqrt(-1);
mu=4*pi*1e-7;
zR=zR-zT;%using the relative Z coordinate
%!!!digits(50); % using digits more than 32 for high accuracy,if neccesary
%model0 parameters
bc0=model0(1,1);
h0=model0(1,2);
uu0=(L^2+J*w*mu*bc0);
u0=(sqrt(uu0));
v0=(bc0/u0);
gama0=(1/u0);
%for the source located at the middle layer
if length(modelM)~=1
 [M,bcM,zM,uM,vM,gamaM,ZM,YM,RM,XM]=make_M(L,w,zT,modelM,v0,gama0);  
end
if length(modelN)~=1
 [N,bcN,zN,uN,vN,gamaN,ZN,YN,RN,XN]=make_N(L,w,zT,modelN,v0,gama0); 
end

%for the source located at the topmost or bottom layer,return the coefficents
%of the vector potentials by magnetic dipole
if length(modelM)==1 % source in the bottom layer 
  [C0MM,C0NN,CMM,CNN]=makeMD_M0(L,zR,model0,w,N,bcN,zN,uN,vN,gamaN,ZN,YN,RN,XN);   
end
if length(modelN)==1 % source in the topmost layer
  [C0MM,C0NN,CMM,CNN]=makeMD_N0(L,zR,model0,w,M,bcM,zM,uM,vM,gamaM,ZM,YM,RM,XM);  
end 
  
% for the source located at middle layer, calculate the coefficents of the vector potentials 
if length(modelM)~=1&&length(modelN)~=1 % source in the middle layers 
%coefficents in the layers beneath the source
    AM=zeros(M,1);BM=zeros(M,1);
    CM=zeros(M,1);DM=zeros(M,1);
    PM=zeros(M,1);QM=zeros(M,1);
    
    A0M=(exp(u0*zR-2*u0*zM(1))+RN*exp(u0*zR-2*u0*h0))/(RM-RN*exp(-2*u0*h0));
    B0M=RM*(RN*exp(2*u0*zN(1)-u0*zR)+exp(-u0*zR))/(RM-RN*exp(-2*u0*h0));
  
    C0M=(XN*exp(u0*zR-2*u0*h0)-exp(u0*zR-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0));
    D0M=(XM)*(XN*exp(2*u0*zN(1)-u0*zR)-exp(-u0*zR))/(XM-XN*exp(-2*u0*h0));
   
    P0M=(exp(u0*zR-2*u0*zM(1))+XN*exp(u0*zR-2*u0*h0))/(XM-XN*exp(-2*u0*h0));
    Q0M=XM*(XN*exp(2*u0*zN(1)-u0*zR)+exp(-u0*zR))/(XM-XN*exp(-2*u0*h0));
    
    UA=(ZM(1)-vM(1))/(ZM(1)-v0);
    UB=(ZM(1)+vM(1))/(ZM(1)+v0);
    UC=(YM(1)-gamaM(1))/(YM(1)-gama0);
    UD=(YM(1)+gamaM(1))/(YM(1)+gama0);
   
    AXP=uM(1)*zR+zM(1)*(u0-uM(1));
    AM(1)=UA*(exp(AXP-2*u0*zM(1))+RN*exp(AXP-2*u0*h0))/(RM-RN*exp(-2*u0*h0))*(bc0/bcM(1));
    CM(1)=UC*(XN*exp(AXP-2*u0*h0)-exp(AXP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0));
    PM(1)=UC*(exp(AXP-2*u0*zM(1))+XN*exp(AXP-2*u0*h0))/(XM-XN*exp(-2*u0*h0));
    
    BXP=-uM(1)*zR+zM(1)*(uM(1)-u0);
    BM(1)=UB*(RM*RN*exp(2*u0*zN(1)+BXP)+exp(BXP)*RM)/(RM-RN*exp(-2*u0*h0))*(bc0/bcM(1));
    DM(1)=UD*(XM)*(XN*exp(2*u0*zN(1)+BXP)-exp(BXP))/(XM-XN*exp(-2*u0*h0));
    QM(1)=UD*(XM*XN*exp(2*u0*zN(1)+BXP)+exp(BXP)*XM)/(XM-XN*exp(-2*u0*h0));
       
    if M>1
        AXP=zM(1)*(u0-uM(1));
        BXP=zM(1)*(uM(1)-u0);
        for i=2:M
           
            UA=UA*(ZM(i)-vM(i))/(ZM(i)-vM(i-1));
            AXP=AXP+zM(i)*(uM(i-1)-uM(i));
            AM(i)=(exp(uM(i)*zR+AXP-2*u0*zM(1))+RN*exp(uM(i)*zR+AXP-2*u0*h0))/(RM-RN*exp(-2*u0*h0))*UA*(bc0/bcM(i));  
                        
            UB=UB*(ZM(i)+vM(i))/(ZM(i)+vM(i-1));
            BXP=BXP+zM(i)*(uM(i)-uM(i-1));
            BM(i)=(RM*RN*exp(2*u0*zN(1)+BXP-uM(i)*zR)+exp(BXP-uM(i)*zR)*RM)/(RM-RN*exp(-2*u0*h0))*UB*(bc0/bcM(i));
                       
            UC=UC*(YM(i)-gamaM(i))/(YM(i)-gamaM(i-1));
            CM(i)=(XN*exp(uM(i)*zR+AXP-2*u0*h0)-exp(uM(i)*zR+AXP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0))*UC;
            PM(i)=(exp(AXP-2*u0*zM(1)+uM(i)*zR)+XN*exp(AXP-2*u0*h0+uM(i)*zR))/(XM-XN*exp(-2*u0*h0))*UC;       
                             
            UD=UD*(YM(i)+gamaM(i))/(YM(i)+gamaM(i-1));
            DM(i)=(XM)*(XN*exp(2*u0*zN(1)+BXP-uM(i)*zR)-exp(BXP-uM(i)*zR))/(XM-XN*exp(-2*u0*h0))*UD;                         
            QM(i)=(XM*XN*exp(2*u0*zN(1)+BXP-uM(i)*zR)+exp(BXP-uM(i)*zR)*XM)/(XM-XN*exp(-2*u0*h0))*UD;    
        end
    end
    
%coefficents in the layers above the source
    AN=zeros(N,1);BN=zeros(N,1); 
    CN=zeros(N,1);DN=zeros(N,1);
    PN=zeros(N,1);QN=zeros(N,1);
   
    A0N=(exp(u0*zR-2*u0*zM(1))+exp(u0*zR)*RM)/(RM-RN*exp(-2*u0*h0));
    B0N=RN*(exp(-2*u0*h0-u0*zR)+RM*exp(2*u0*zN(1)-u0*zR))/(RM-RN*exp(-2*u0*h0));
  
    C0N=(exp(u0*zR)*XM-exp(u0*zR-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0));
    D0N=XN*(XM*exp(2*u0*zN(1)-u0*zR)-exp(-2*u0*h0-u0*zR))/(XM-XN*exp(-2*u0*h0));
 
    P0N=(exp(u0*zR-2*u0*zM(1))+exp(u0*zR)*XM)/(XM-XN*exp(-2*u0*h0));
    Q0N=XN*(exp(-2*u0*h0-u0*zR)+XM*exp(2*u0*zN(1)-u0*zR))/(XM-XN*exp(-2*u0*h0));
    
    UA=(ZN(1)-vN(1))/(ZN(1)-v0);
    UB=(ZN(1)+vN(1))/(ZN(1)+v0);
    UC=(YN(1)-gamaN(1))/(YN(1)-gama0);
    UD=(YN(1)+gamaN(1))/(YN(1)+gama0);
       
    AXP=uN(1)*zR+zN(1)*(u0-uN(1));
    AN(1)=(exp(AXP-2*u0*zM(1))+exp(AXP)*RM)/(RM-RN*exp(-2*u0*h0))*UA*(bc0/bcN(1)); 
    CN(1)=(exp(AXP)*XM-exp(AXP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0))*UC;
    PN(1)=(exp(AXP-2*u0*zM(1))+exp(AXP)*XM)/(XM-XN*exp(-2*u0*h0))*UC;
    
    BXP=-uN(1)*zR+zN(1)*(uN(1)-u0);
    BN(1)=RN*(exp(BXP-2*u0*h0)+RM*exp(BXP+2*u0*zN(1)))/(RM-RN*exp(-2*u0*h0))*UB*(bc0/bcN(1)); 
    DN(1)=XN*(XM*exp(2*u0*zN(1)+BXP)-exp(BXP-2*u0*h0))/(XM-XN*exp(-2*u0*h0))*UD;
    QN(1)=XN*(exp(BXP-2*u0*h0)+XM*exp(2*u0*zN(1)+BXP))/(XM-XN*exp(-2*u0*h0))*UD;
       
    if N>1
        AXP=zN(1)*(u0-uN(1));
        BXP=zN(1)*(uN(1)-u0);       
        for j=2:N
            
            UA=UA*(ZN(j)-vN(j))/(ZN(j)-vN(j-1));
            AXP=AXP+zN(j)*(uN(j-1)-uN(j));
            AN(j)=(exp(AXP-2*u0*zM(1)+uN(j)*zR)+exp(AXP+uN(j)*zR)*RM)/(RM-RN*exp(-2*u0*h0))*UA*(bc0/bcN(j));
                      
            UB=UB*(ZN(j)+vN(j))/(ZN(j)+vN(j-1));
            BXP=BXP+zN(j)*(uN(j)-uN(j-1));
            BN(j)=RN*(exp(BXP-2*u0*h0-uN(j)*zR)+RM*exp(BXP+2*u0*zN(1)-uN(j)*zR))/(RM-RN*exp(-2*u0*h0))*UB*(bc0/bcN(j));
            
            UC=UC*(YN(j)-gamaN(j))/(YN(j)-gamaN(j-1));
            CN(j)=(exp(AXP+uN(j)*zR)*XM-exp(AXP-2*u0*zM(1)+uN(j)*zR))/(XM-XN*exp(-2*u0*h0))*UC;
            PN(j)=(exp(AXP-2*u0*zM(1)+uN(j)*zR)+exp(AXP+uN(j)*zR)*XM)/(XM-XN*exp(-2*u0*h0))*UC;
            
            UD=UD*(YN(j)+gamaN(j))/(YN(j)+gamaN(j-1));
            DN(j)=XN*(XM*exp(2*u0*zN(1)+BXP-uN(j)*zR)-exp(BXP-2*u0*h0-uN(j)*zR))/(XM-XN*exp(-2*u0*h0))*UD;
            QN(j)=XN*(exp(BXP-2*u0*h0-uN(j)*zR)+XM*exp(2*u0*zN(1)+BXP-uN(j)*zR))/(XM-XN*exp(-2*u0*h0))*UD;                                          
        end
    end
    
%preparation for output
    CMM=zeros(M,11);
    CNN=zeros(N,11);
    C0MM=[A0M,B0M,C0M,D0M,P0M,Q0M,u0,v0,gama0,bc0,w];
    C0NN=[A0N,B0N,C0N,D0N,P0N,Q0N,u0,v0,gama0,bc0,w];
    for m=1:M
        CMM(m,1:11)=[AM(m),BM(m),CM(m),DM(m),PM(m),QM(m),uM(m),vM(m),gamaM(m),bcM(m),w];
    end
    for n=1:N
        CNN(n,1:11)=[AN(n),BN(n),CN(n),DN(n),PN(n),QN(n),uN(n),vN(n),gamaN(n),bcN(n),w];
    end
end
end

function [G]=tanhG(a)
expa=(exp(-2*a));
G=((1-expa)/(1+expa));
end

function [M,bcM,zM,uM,vM,gamaM,ZM,YM,RM,XM]=make_M(L,w,zT,modelM,v0,gama0)
J=sqrt(-1);
mu=4*pi*1e-7;
M=size(modelM,1);
modelM(:,3)=modelM(:,3)-zT;
bcM=modelM(:,1);
hM=modelM(:,2);
zM=modelM(:,3);
uM=zeros(M,1);
vM=zeros(M,1);
gamaM=zeros(M,1);
ZM=zeros(M,1);
YM=zeros(M,1);

for i=1:M    
    uM(i)=sqrt(L^2+J*w*mu*bcM(i));     
    vM(i)=(bcM(i)/uM(i));           
    gamaM(i)=(1/uM(i));             
end
ZM(M)=vM(M);                        
YM(M)=gamaM(M);                     
if M>1
    for i=M-1:-1:1                 
        ZM(i)=vM(i)*(ZM(i+1)+vM(i)*tanhG(uM(i)*hM(i)))/(vM(i)+ZM(i+1)*tanhG(uM(i)*hM(i)));         
        YM(i)=gamaM(i)*(YM(i+1)+gamaM(i)*tanhG(uM(i)*hM(i)))/(gamaM(i)+YM(i+1)*tanhG(uM(i)*hM(i)));
    end
end
RM=((ZM(1)+v0)/(ZM(1)-v0));          
XM=((YM(1)+gama0)/(YM(1)-gama0));    
end

function [N,bcN,zN,uN,vN,gamaN,ZN,YN,RN,XN]=make_N(L,w,zT,modelN,v0,gama0) 
J=sqrt(-1);
mu=4*pi*1e-7;
N=size(modelN,1);
modelN(:,3)=modelN(:,3)-zT;
bcN=modelN(:,1);
hN=modelN(:,2);
zN=modelN(:,3);
uN=zeros(N,1);
vN=zeros(N,1);
gamaN=zeros(N,1);
ZN=zeros(N,1);
YN=zeros(N,1);

for j=1:N
    uN(j)=sqrt(L^2+J*w*mu*bcN(j));    
    vN(j)=(bcN(j)/uN(j));
    gamaN(j)=(1/uN(j));
end
ZN(N)=-vN(N);                      
YN(N)=-gamaN(N);                    
if N>1
    for j=N-1:-1:1                 
        ZN(j)=vN(j)*(ZN(j+1)-vN(j)*tanhG(uN(j)*hN(j)))/(vN(j)-ZN(j+1)*tanhG(uN(j)*hN(j)));
        YN(j)=gamaN(j)*(YN(j+1)-gamaN(j)*tanhG(uN(j)*hN(j)))/(gamaN(j)-YN(j+1)*tanhG(uN(j)*hN(j)));
    end
end
RN=((ZN(1)+v0)/(ZN(1)-v0));          
XN=((YN(1)+gama0)/(YN(1)-gama0));
end


