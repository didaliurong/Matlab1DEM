%input*************model description  *******************
bc=[1d-12,   3.3      1       0.01     0.1      0.05    0.01];%conductivity of each layers(from topmost to bottom layer);
h=[1d60,     500     1000     500     500      1000     1d60];%thickness of each layer
z=[      0        500     1500    2000     2500     3500    ];%interface
%design the Tx-Rx
TX=[0,0,1750];                                                %position of the transmitter
T0=4;                                                         % the transmitter is the 4th layer
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers
f=1;                               %frequency of the transmitter
%positions of the receivers (here xxB is the range of bisector x=y )
xxB=-8200:400:8200;
yyB=0;
zzB=0.1:200:4000.1;
P=length(xxB)*length(yyB)*length(zzB);
PS=zeros(P,3);
for i=1:length(xxB)
    for j=1:length(yyB)
        for k=1:length(zzB)
            m=(i-1)*length(yyB)*length(zzB)+(j-1)*length(zzB)+k;
            PS(m,1)=xxB(i);
            PS(m,2)=yyB(j);
            PS(m,3)=zzB(k);
        end
    end
end% end of the input***********

[ XEx,XEy,XEz ]=E_XED_XY(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric dipole
XEx=sqrt(XEx.^2+XEy.^2); %transform the x- and y- directed fields into bisector x=y plan

%output the result
filename1=strcat(num2str(f),'Hz','example XED caused electric vector in 7 layer model.txt');
fid1=fopen(filename1,'wt');
for i=1:P
    fprintf(fid1,'%12.5g\t',PS(i,1));
    fprintf(fid1,'%12.5g\t',PS(i,3));
    fprintf(fid1,'%12.5g\t',real(XEx(i)));
    fprintf(fid1,'%12.5g\t',imag(XEx(i)));
    fprintf(fid1,'%12.5g\t',real(XEz(i)));
    fprintf(fid1,'%12.5g\n',imag(XEz(i)));
end

ExB_inphase=zeros(length(zzB),length(xxB));
ExB_outphase=zeros(length(zzB),length(xxB));
EzB_inphase=zeros(length(zzB),length(xxB));
EzB_outphase=zeros(length(zzB),length(xxB));
ESB_inphase=zeros(length(zzB),length(xxB));
ESB_outphase=zeros(length(zzB),length(xxB));
for i=1:length(xxB)
    for j=1:length(zzB)
        k=(i-1)*length(zzB)+j;
        
        ExB_inphase(j,i)=real(XEx(k));
        ExB_outphase(j,i)=imag(XEx(k));
        EzB_inphase(j,i)=real(XEz(k));
        EzB_outphase(j,i)=imag(XEz(k));
        ESB_inphase(j,i)=log10((sqrt(real(XEx(k))^2+real(XEz(k))^2)));
        ESB_outphase(j,i)=log10((sqrt(imag(XEx(k))^2+imag(XEz(k))^2)));
    end
end

[ XHx,XHy,XHz ]=H_XED_XY(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the magnetic fields by x-directed electric dipole
XHx=sqrt(XHx.^2+XHy.^2); %transform the x- and y- directed fields into bisector x=y plan

%output the result
filename2=strcat(num2str(f),'Hz','example XED caused magnetic vector in 7 layer model.txt.txt');
fid2=fopen(filename2,'wt');
for i=1:P
    fprintf(fid2,'%12.5g\t',PS(i,1));
    fprintf(fid2,'%12.5g\t',PS(i,3));
    fprintf(fid2,'%12.5g\t',real(XHx(i)));
    fprintf(fid2,'%12.5g\t',imag(XHx(i)));
    fprintf(fid2,'%12.5g\t',real(XHz(i)));
    fprintf(fid2,'%12.5g\n',imag(XHz(i)));
end

HxB_inphase=zeros(length(zzB),length(xxB));
HxB_outphase=zeros(length(zzB),length(xxB));
HzB_inphase=zeros(length(zzB),length(xxB));
HzB_outphase=zeros(length(zzB),length(xxB));
HSB_inphase=zeros(length(zzB),length(xxB));
HSB_outphase=zeros(length(zzB),length(xxB));
for i=1:length(xxB)
    for j=1:length(zzB)
        k=(i-1)*length(zzB)+j;
        
        HxB_inphase(j,i)=real(XHx(k));
        HxB_outphase(j,i)=imag(XHx(k));
        HzB_inphase(j,i)=real(XHz(k));
        HzB_outphase(j,i)=imag(XHz(k));
        HSB_inphase(j,i)=log10((sqrt(real(XHx(k))^2+real(XHz(k))^2)));
        HSB_outphase(j,i)=log10((sqrt(imag(XHx(k))^2+imag(XHz(k))^2)));
    end
end



