function [CMM,u0] = CAL_EDabcdpq_validation(L,model0,modelM,modelN,zR,zT,w)

%calculate the coefficient of potentials 
%have used more digits for higher calculation precision

%%
J=sqrt(-1);
mu=4*pi*1e-7;

zR=zR-zT;
bc0=model0(1,1);
h0=model0(1,2);


digits(50); 

u0=vpa(sqrt(L^2+J*w*mu*bc0));
v0=vpa(1/u0);
k0=vpa(sqrt(J*w*mu*bc0));
gama0=vpa(k0^2/u0);


if length(modelM)~=1
 [M,bcM,zM,uM,vM,gamaM,ZM,YM,RM,XM]=make_M(L,w,zT,modelM,v0,gama0);  
end

if length(modelN)~=1
 [N,bcN,zN,uN,vN,gamaN,ZN,YN,RN,XN]=make_N(L,w,zT,modelN,v0,gama0); 
end
        
    %coefficient for layer M=1   
    UA=(ZM(1)-vM(1))/(ZM(1)-v0);
    UB=(ZM(1)+vM(1))/(ZM(1)+v0);
    UC=(YM(1)-gamaM(1))/(YM(1)-gama0);
    UD=(YM(1)+gamaM(1))/(YM(1)+gama0);
    
    XP=uM(1)*zR+zM(1)*(u0-uM(1));
    AM=UA*(exp(XP-2*u0*zM(1))+RN*exp(XP-2*u0*h0))/(RM-RN*exp(-2*u0*h0));
    
    XP=-uM(1)*zR+zM(1)*(uM(1)-u0);
    BM=UB*(RM*RN*exp(2*u0*zN(1)+XP)+exp(XP)*RM)/(RM-RN*exp(-2*u0*h0));
   
    XP=uM(1)*zR+zM(1)*(u0-uM(1));
    CM=UC*(XN*exp(XP-2*u0*h0)-exp(XP-2*u0*zM(1)))/(XM-XN*exp(-2*u0*h0));
    
    XP=-uM(1)*zR+zM(1)*(uM(1)-u0);
    DM=UD*(XM)*(XN*exp(2*u0*zN(1)+XP)-exp(XP))/(XM-XN*exp(-2*u0*h0));

    XP=uM(1)*zR+zM(1)*(u0-uM(1));
    PM=UC*(exp(XP-2*u0*zM(1))+XN*exp(XP-2*u0*h0))/(XM-XN*exp(-2*u0*h0));
  
    XP=-uM(1)*zR+zM(1)*(uM(1)-u0);
    QM=UD*(XM*XN*exp(2*u0*zN(1)+XP)+exp(XP)*XM)/(XM-XN*exp(-2*u0*h0));
    
    CMM=[AM,BM,CM,DM,PM,QM,uM(1),vM(1),gamaM(1),bcM(1),w];
    
end

function [G]=tanhG(a)
digits(50);
G=vpa((1-exp(-2*a))/(1+exp(-2*a)));
end

function [M,bcM,zM,uM,vM,gamaM,ZM,YM,RM,XM]=make_M(L,w,zT,modelM,v0,gama0)
J=sqrt(-1);
mu=4*pi*1e-7;
M=size(modelM,1);
modelM(:,3)=modelM(:,3)-zT;
bcM=modelM(:,1);
hM=modelM(:,2);
zM=modelM(:,3);
uM=zeros(M,1);
vM=zeros(M,1);
kM=zeros(M,1);
gamaM=zeros(M,1);
ZM=zeros(M,1);
YM=zeros(M,1);
digits(50);

for i=1:M
    uM(i)=vpa(sqrt(L^2+J*w*mu*bcM(i)));    
    vM(i)=vpa(1/uM(i));                    
    kM(i)=vpa(sqrt(J*w*mu*bcM(i)));        
    gamaM(i)=vpa(kM(i)^2/uM(i));           
end
ZM(M)=vM(M);                               
YM(M)=gamaM(M);                            
if M>1
    for i=M-1:-1:1 
        ZM(i)=vM(i)*(ZM(i+1)+vM(i)*tanhG(uM(i)*hM(i)))/(vM(i)+ZM(i+1)*tanhG(uM(i)*hM(i)));         
        YM(i)=gamaM(i)*(YM(i+1)+gamaM(i)*tanhG(uM(i)*hM(i)))/(gamaM(i)+YM(i+1)*tanhG(uM(i)*hM(i)));
    end
end
RM=(ZM(1)+v0)/(ZM(1)-v0);          
XM=(YM(1)+gama0)/(YM(1)-gama0);     
end

function [N,bcN,zN,uN,vN,gamaN,ZN,YN,RN,XN]=make_N(L,w,zT,modelN,v0,gama0) 
J=sqrt(-1);
mu=4*pi*1e-7;
N=size(modelN,1);
modelN(:,3)=modelN(:,3)-zT;
bcN=modelN(:,1);
hN=modelN(:,2);
zN=modelN(:,3);
uN=zeros(N,1);
vN=zeros(N,1);
kN=zeros(N,1);
gamaN=zeros(N,1);
ZN=zeros(N,1);
YN=zeros(N,1);

digits(50);

for j=1:N
    uN(j)=vpa(sqrt(L^2+J*w*mu*bcN(j)));
    vN(j)=vpa(1/uN(j));
    kN(j)=vpa(sqrt(J*w*mu*bcN(j)));
    gamaN(j)=vpa(kN(j)^2/uN(j));
end
ZN(N)=-vN(N);                      
YN(N)=-gamaN(N);                    
if N>1
    for j=N-1:-1:1 
        ZN(j)=vN(j)*(ZN(j+1)-vN(j)*tanhG(uN(j)*hN(j)))/(vN(j)- ZN(j+1)*tanhG(uN(j)*hN(j)));     
        YN(j)=gamaN(j)*(YN(j+1)-gamaN(j)*tanhG(uN(j)*hN(j)))/(gamaN(j)-YN(j+1)*tanhG(uN(j)*hN(j)));
    end
end
RN=(ZN(1)+v0)/(ZN(1)-v0);           
XN=(YN(1)+gama0)/(YN(1)-gama0);
end


