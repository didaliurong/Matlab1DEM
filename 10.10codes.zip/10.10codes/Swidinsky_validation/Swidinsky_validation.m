
% Comparing the results with Swidinsky et al(2018) on a marine model
%model description
bc=[1d-12,   3            1        0.1 ];%the conductivity from topmost layer to deepest layer
h=[1d60,    1000        1000       1d60 ];%the thickness 
z=[      0       1000         2000      ];%the interface
%design the Tx-Rx
TX=[0,0,950];                                               %position of the transmitter
PS=[1000,1000,1950];                                        % position of the receiver
T0=2;                                     % the source layer is the 2th layer (seawater layer)
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers 
ff=[0.0000001,1,100]; %frequencies of the transmitter

ww=2*pi*ff;
dx=PS(1,1)-TX(1,1);
dy=PS(1,2)-TX(1,2);
R=sqrt(dx^2+dy^2);
zR=PS(1,3);
zT=TX(1,3);

lambda    = 10.^(-5.5:0.0666:0);%discrete lambda point 
BJ0=ones(length(lambda),1);%the weight of each lambda point is assumed 1
BJ1=ones(length(lambda),1);%the weight of each lambda point is assumed 1

Jx=zeros(length(lambda),1);
Jy=zeros(length(lambda),1);
Jz=zeros(length(lambda),1);
Bx=zeros(length(lambda),1);
By=zeros(length(lambda),1);
Bz=zeros(length(lambda),1);

for k=1:3
    w=ww(k);
for i=1:length(lambda)
    EyK=[0,0,0,0,0,0];
    [CM,u0] = CAL_EDabcdpq_validation(lambda(i),Tmodel0,TmodelM,TmodelN,zR,zT,w);%return the coefficents of the vector potential at the receiver
    EyK(1,1:6) = validation_E(lambda(i),R,dx,dy,CM,u0);%return the value of kernel function (electric field) for each lambda
    HyK(1,1:6) = validation_H(lambda(i),R,dx,dy,CM,u0);%return the value of kernel function (magnetic field) for each lambda
    
    fE=[0,0,0];
    fH=[0,0,0]; 
    %calculate the J and B
    fE(1)=(EyK(1,1)*BJ0(i)) +  (EyK(1,2)*BJ1(i));%the field is make up of J0 and J1 parts
    fE(2)=(EyK(1,3)*BJ0(i)) +  (EyK(1,4)*BJ1(i));
    fE(3)=(EyK(1,5)*BJ0(i)) +  (EyK(1,6)*BJ1(i));
    fH(1)=(HyK(1,1)*BJ0(i)) +  (HyK(1,2)*BJ1(i));
    fH(2)=(HyK(1,3)*BJ0(i)) +  (HyK(1,4)*BJ1(i));
    fH(3)=(HyK(1,5)*BJ0(i)) +  (HyK(1,6)*BJ1(i));        
    Jx(i,k) = fE(1);
    Jy(i,k) = fE(2);
    Jz(i,k) = fE(3);
    Bx(i,k) = 4*pi*1d-7*fH(1);
    By(i,k) = 4*pi*1d-7*fH(2);
    Bz(i,k) = 4*pi*1d-7*fH(3);
end
end

%data from Swidinsky et al  2018
image11=importdata('11 -image.txt');
image12=importdata('12 -image.txt');
image21=importdata('21 -image.txt');
image22=importdata('22 -image.txt');
image31=importdata('31 -image.txt');
image32=importdata('32 -image.txt');

real11=importdata('11 -real.txt');
real12=importdata('12 -real.txt');
real21=importdata('21 -real.txt');
real22=importdata('22 -real.txt');
real31=importdata('31 -real.txt');
real32=importdata('32 -real.txt');

%plot the result 
figure(1);
subplot(3,2,1)
plot(log10(lambda),-real(Jz(:,1)),'r-',...
     log10(lambda),-imag(Jz(:,1)),'b-',...
     log10(lambda),real11(:,2)*1d-9,'r.',...
     log10(lambda),image11(:,2)*1d-9,'b.')
%xlabel('log10(lambda)','FontName','Times New Roman','FontSize',20)
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',10)
ylabel('0.0001Hz','FontName','Times New Roman','FontSize',10)
h1=legend('real','imag');
set(h1,'FontName','Times New Roman','FontSize',10)
h2=title('Jz kernel(A/m)');
set(h2,'FontName','Times New Roman','FontSize',10)
axis square

subplot(3,2,3)
plot(log10(lambda),-real(Jz(:,2)),'r-',...
     log10(lambda),-imag(Jz(:,2)),'b-',...
     log10(lambda),real21(:,2)*1d-9,'r.',...
     log10(lambda),image21(:,2)*1d-9,'b.')
%xlabel('log10(lambda)','FontName','Times New Roman','FontSize',20)
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',10)
ylabel('1Hz','FontName','Times New Roman','FontSize',10)
h1=legend('real','imag');
set(h1,'FontName','Times New Roman','FontSize',10)
axis square

subplot(3,2,5)
plot(log10(lambda),-real(Jz(:,3)),'r-',...
     log10(lambda),-imag(Jz(:,3)),'b-',...
     log10(lambda),real31(:,2)*1d-15,'r.',...
     log10(lambda),image31(:,2)*1d-15,'b.')
set(gca,'FontName','Times New Roman','FontSize',10)
xlabel('log10(\lambda)','FontName','Times New Roman','FontSize',10)
ylabel('100Hz','FontName','Times New Roman','FontSize',10)
h1=legend('real','imag');
set(h1,'FontName','Times New Roman','FontSize',10)
axis square

subplot(3,2,2)
plot(log10(lambda),-real(Bz(:,1)),'r-',...
     log10(lambda),-imag(Bz(:,1)),'b-',...
     log10(lambda),real12(:,2)*1d-11,'r.',...
     log10(lambda),image12(:,2)*1d-11,'b.')
%xlabel('log10(lambda)','FontName','Times New Roman','FontSize',20)
%ylabel('Bz kernel(A/m)','FontName','Times New Roman','FontSize',20)
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',10)
h1=legend('real','imag');
set(h1,'FontName','Times New Roman','FontSize',10)
h2=title('Bz kernel(T.m)');
set(h2,'FontName','Times New Roman','FontSize',10)
axis square

subplot(3,2,4)
plot(log10(lambda),-real(Bz(:,2)),'r-',...
     log10(lambda),-imag(Bz(:,2)),'b-',...
     log10(lambda),real22(:,2)*1d-12,'r.',...
     log10(lambda),image22(:,2)*1d-12,'b.')
%xlabel('log10(lambda)','FontName','Times New Roman','FontSize',20)
%ylabel('Bz kernel(A/m)','FontName','Times New Roman','FontSize',20)
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',10)
h1=legend('real','imag');
set(h1,'FontName','Times New Roman','FontSize',10)
axis square

subplot(3,2,6)
plot(log10(lambda),-real(Bz(:,3)),'r-',...
     log10(lambda),-imag(Bz(:,3)),'b-',...
     log10(lambda),real32(:,2)*1d-20,'r.',...
     log10(lambda),image32(:,2)*1d-20,'b.')
set(gca,'FontName','Times New Roman','FontSize',10)
xlabel('log10(\lambda)','FontName','Times New Roman','FontSize',10)
%ylabel('Bz kernel(A/m)','FontName','Times New Roman','FontSize',20)
h1=legend('real','imag');
set(h1,'FontName','Times New Roman','FontSize',10)
axis square