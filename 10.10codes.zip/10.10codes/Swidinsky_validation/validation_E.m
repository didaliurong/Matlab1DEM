function EyKernels =validation_E(L,R,dx,dy,CM,u0)

 A=CM(1);B=CM(2);C=CM(3);D=CM(4);P=CM(5);Q=CM(6);u=CM(7);bc=CM(10);w=CM(11);      
 A=(L/u0)*A;B=(L/u0)*B;C=(1/L)*C;D=(1/L)*D;P=(L/u0)*P;Q=(L/u0)*Q;
 %the coefficents from differential 
 P0XY=dx*dy/(4*pi*R^2);
 P1XY=2*dx*dy/(4*pi*R^3); 
 P0XX=dx^2/(4*pi*R^2);
 P1XX=(2*dx^2-R^2)/(4*pi*R^3);
 %potentials
 A11J0=1/(4*pi)*(A+B);
 A11J1=0;
 A21J0=0;
 A21J1=0;
 A31J0=0;
 A31J1=dx/(4*pi*R)*(-L*(C+D-(u/L^2)*A+(u/L^2)*B));
 %differential of potentials
 V11J0=-P0XX*(L^2*(A+B))-P0XX*(L^2*u*(C-D-(u/L^2)*A-(u/L^2)*B));
 V11J1=P1XX*(L*(A+B))+P1XX*(L*u*(C-D-(u/L^2)*A-(u/L^2)*B));
 V21J0=-P0XY*(L^2*(A+B))-P0XY*(L^2*u*(C-D-(u/L^2)*A-(u/L^2)*B));
 V21J1=P1XY*(L*(A+B))+P1XY*(L*u*(C-D-(u/L^2)*A-(u/L^2)*B));
 V31J0=0;
 V31J1=dx/(4*pi*R)*(-L*u*(A-B))+dx/(4*pi*R)*(-L*u^2*(C+D-(u/L^2)*A+(u/L^2)*B));
 
 %electric fields
 J=sqrt(-1);
 mu=4*pi*1e-7;
 %the x-directed electric field by x-directed unit electrc dipole
 EXxJ0=-J*w*mu*A11J0+1/bc*V11J0;
 EXxJ1=-J*w*mu*A11J1+1/bc*V11J1;
 %the y-directed electric field by x-directed unit electrc dipole
 EXyJ0=-J*w*mu*A21J0+1/bc*V21J0;
 EXyJ1=-J*w*mu*A21J1+1/bc*V21J1;
 %the z-directed electric field by x-directed unit electrc dipole
 EXzJ0=-J*w*mu*A31J0+1/bc*V31J0;
 EXzJ1=-J*w*mu*A31J1+1/bc*V31J1;
 
 EyKernels=[EXxJ0 EXxJ1 EXyJ0 EXyJ1 EXzJ0 EXzJ1];
 end

