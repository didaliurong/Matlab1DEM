%%background model
%input*************model description  *******************
bc=[1d-12,   3.3                1];%conducutivity from topmost layer to deepest layer
h=[1d60,    1000             1d60];%thickness from topmost layer to deepest layer
z=[      0       1000            ];%interface 
%design the Tx-Rx
TX=[0,0,950];                      %position of the transmitter
T0=2;                              % the source layer is the 2th layer 
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers
f=1;                               %frequency of the transmitter
%positions of the receivers
xxB=-8200:400:8200;
yyB=0;
zzB=0.1:200:4000.1;
P=length(xxB)*length(yyB)*length(zzB);
PS=zeros(P,3);
for i=1:length(xxB)
  for j=1:length(yyB)
      for k=1:length(zzB)
        m=(i-1)*length(yyB)*length(zzB)+(j-1)*length(zzB)+k;
        PS(m,1)=xxB(i);
        PS(m,2)=yyB(j);
        PS(m,3)=zzB(k);
      end
  end
end%end input*************

 [ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric source 

%output results        
filename1=strcat(num2str(f),'Hz','marine 1D electric vector in background model.txt');
fid1=fopen(filename1,'wt');
for i=1:P
    fprintf(fid1,'%12.5g\t',PS(i,1));
    fprintf(fid1,'%12.5g\t',PS(i,3));  
    fprintf(fid1,'%12.5g\t',real(XEx(i)));
    fprintf(fid1,'%12.5g\t',imag(XEx(i)));
    fprintf(fid1,'%12.5g\t',real(XEz(i)));
    fprintf(fid1,'%12.5g\n',imag(XEz(i)));
end

ExB_inphase=zeros(length(zzB),length(xxB));
ExB_outphase=zeros(length(zzB),length(xxB));
EzB_inphase=zeros(length(zzB),length(xxB));
EzB_outphase=zeros(length(zzB),length(xxB));
ESB_inphase=zeros(length(zzB),length(xxB));
ESB_outphase=zeros(length(zzB),length(xxB));
for i=1:length(xxB)
for j=1:length(zzB)    
    k=(i-1)*length(zzB)+j;
    if zzB(j)<1000
    ExB_inphase(j,i)=3.3*real(XEx(k));  
    ExB_outphase(j,i)=3.3*imag(XEx(k));
    EzB_inphase(j,i)=3.3*real(XEz(k));  
    EzB_outphase(j,i)=3.3*imag(XEz(k));
    ESB_inphase(j,i)=log10(3.3*(sqrt(real(XEx(k))^2+real(XEz(k))^2)));  
    ESB_outphase(j,i)=log10(3.3*(sqrt(imag(XEx(k))^2+imag(XEz(k))^2)));
    
        else
    ExB_inphase(j,i)=real(XEx(k));  
    ExB_outphase(j,i)=imag(XEx(k));
    EzB_inphase(j,i)=real(XEz(k));  
    EzB_outphase(j,i)=imag(XEz(k));      
    ESB_inphase(j,i)=log10(sqrt(real(XEx(k))^2+real(XEz(k))^2));  
    ESB_outphase(j,i)=log10(sqrt(imag(XEx(k))^2+imag(XEz(k))^2));        
    end    
end
end
%%

%%1Dreservoir model
%input*************model description  *******************
bc=[1d-12,   3.3           1        0.01         1];
h=[1d60,    1000        1000        100       1d60];
z=[      0       1000         2000      2100      ];

%design Tx-Rx
TX=[0,0,950];
T0=2;
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);
%positions of the receivers
xx=-8200:400:8200;
yy=0;
zz=0.1:200:4000.1;
P=length(xx)*length(yy)*length(zz);
PS=zeros(P,3);
for i=1:length(xx)
  for j=1:length(yy)
      for k=1:length(zz)
        m=(i-1)*length(yy)*length(zz)+(j-1)*length(zz)+k;
        PS(m,1)=xx(i);
        PS(m,2)=yy(j);
        PS(m,3)=zz(k);
      end
  end
end%end input*********

 [ XEx,XEy,XEz ]=E_XED(PS,TX,Tmodel0,TmodelM,TmodelN,f);%return the electric fields by x-directed electric source 

%output results               
filename2=strcat(num2str(f),'Hz','marine 1D electric vector in reservior model.txt');
fid2=fopen(filename2,'wt');
for i=1:P
    fprintf(fid2,'%12.5g\t',PS(i,1));
    fprintf(fid2,'%12.5g\t',PS(i,3));  
    fprintf(fid2,'%12.5g\t',real(XEx(i)));
    fprintf(fid2,'%12.5g\t',imag(XEx(i)));
    fprintf(fid2,'%12.5g\t',real(XEz(i)));
    fprintf(fid2,'%12.5g\n',imag(XEz(i)));
end

Ex_inphase=zeros(length(zz),length(xx));
Ex_outphase=zeros(length(zz),length(xx));
Ez_inphase=zeros(length(zz),length(xx));
Ez_outphase=zeros(length(zz),length(xx));
ES_inphase=zeros(length(zz),length(xx));
ES_outphase=zeros(length(zz),length(xx));
for i=1:length(xx)
for j=1:length(zz)    
    k=(i-1)*length(zz)+j;
    if zz(j)<1000
    Ex_inphase(j,i)=3.3*real(XEx(k));  
    Ex_outphase(j,i)=3.3*imag(XEx(k));
    Ez_inphase(j,i)=3.3*real(XEz(k));  
    Ez_outphase(j,i)=3.3*imag(XEz(k));
    ES_inphase(j,i)=log10(3.3*(sqrt(real(XEx(k))^2+real(XEz(k))^2)));  
    ES_outphase(j,i)=log10(3.3*(sqrt(imag(XEx(k))^2+imag(XEz(k))^2)));
    else if 2000<zz(j)<2100
    Ex_inphase(j,i)=0.01*real(XEx(k));  
    Ex_outphase(j,i)=0.01*imag(XEx(k));
    Ez_inphase(j,i)=0.01*real(XEz(k));  
    Ez_outphase(j,i)=0.01*imag(XEz(k));
    ES_inphase(j,i)=log10(0.01*(sqrt(real(XEx(k))^2+real(XEz(k))^2)));  
    ES_outphase(j,i)=log10(0.01*(sqrt(imag(XEx(k))^2+imag(XEz(k))^2))); 
        else
    Ex_inphase(j,i)=real(XEx(k));  
    Ex_outphase(j,i)=imag(XEx(k));
    Ez_inphase(j,i)=real(XEz(k));  
    Ez_outphase(j,i)=imag(XEz(k));      
    ES_inphase(j,i)=log10(sqrt(real(XEx(k))^2+real(XEz(k))^2));  
    ES_outphase(j,i)=log10(sqrt(imag(XEx(k))^2+imag(XEz(k))^2));        
        end
    end
end
end

