%return the electric fields caused by x-directed unit electric dipole
function [ AEx,AEy,AEz ] = E_XED(PS,PV,model0,modelM,modelN,f)
%parameters of qwe*********
relTol = 1d-12;
absTol = 1d-24;
nQuad  = 51;
nIntervalsMax = 40;
[xIntervals Bx BJ0 BJ1] = getBesselWeights(nIntervalsMax,nQuad,'j1');

AEx=zeros(size(PS,1),size(PV,1));
AEy=zeros(size(PS,1),size(PV,1));
AEz=zeros(size(PS,1),size(PV,1));
w=2*pi*f;
parpool('local',4);
p=gcp('nocreat');
parfor iRx = 1:size(PS,1)
    mytempt=zeros(3,size(PV,1));
    for iTx = 1:size(PV,1)
        dx=PS(iRx,1)-PV(iTx,1);
        dy=PS(iRx,2)-PV(iTx,2);
        R=sqrt(dx^2+dy^2);
        zR=PS(iRx,3);
        zT=PV(iTx,3);
        
        intervals = xIntervals/R;
        lambda    = Bx/R;
        
        TVX = E_qweXED(relTol,absTol,nIntervalsMax,intervals,nQuad,lambda,BJ0,BJ1,R,dx,dy,zR,zT,model0,modelM,modelN,w);
        
        mytempt(1,iTx) = TVX(1).extrap(TVX(1).n);
        mytempt(2,iTx) = TVX(2).extrap(TVX(2).n);
        mytempt(3,iTx) = TVX(3).extrap(TVX(3).n);
    end
    AEx(iRx,:)=mytempt(1,:);
    AEy(iRx,:)=mytempt(2,:);
    AEz(iRx,:)=mytempt(3,:);
end
delete(p);
end


