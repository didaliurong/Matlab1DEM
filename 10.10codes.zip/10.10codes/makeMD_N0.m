function  [C0MM,C0NN,CMM,CNN]=makeMD_N0(L,zR,model0,w,M,bcM,zM,uM,vM,gamaM,ZM,YM,RM,XM)
%return the coefficents of vector potential for magnetic source in the topmost layer
J=sqrt(-1);
mu=4*pi*1e-7;
bc0=model0(1,1);
u0=sqrt(L^2+J*w*mu*bc0);
v0=bc0/u0;
gama0=1/u0;

AM=zeros(M,1);BM=zeros(M,1);
CM=zeros(M,1);DM=zeros(M,1);
PM=zeros(M,1);QM=zeros(M,1);
CNN=0;        CMM=zeros(M,11);

A0M=exp(u0*zR-2*u0*zM(1))/RM; 
C0M=-exp(u0*zR-2*u0*zM(1))/XM;
P0M=exp(u0*zR-2*u0*zM(1))/XM;

B0M=exp(-u0*zR);
D0M=-exp(-u0*zR);
Q0M=exp(-u0*zR);

A0N=exp(u0*zR-2*u0*zM(1))/RM+exp(u0*zR);
C0N=-exp(u0*zR-2*u0*zM(1))/XM+exp(u0*zR);
P0N=exp(u0*zR-2*u0*zM(1))/XM+exp(u0*zR);

B0N=0;
D0N=0;
Q0N=0;

%***CMM
UA=(ZM(1)-vM(1))/(ZM(1)-v0);
UB=(ZM(1)+vM(1))/(ZM(1)+v0);
UC=(YM(1)-gamaM(1))/(YM(1)-gama0);
UD=(YM(1)+gamaM(1))/(YM(1)+gama0);

XP=uM(1)*zR+zM(1)*(u0-uM(1));
AM(1)=(bc0/bcM(1))*UA*exp(XP-2*u0*zM(1))/RM;
CM(1)=UC*(-exp(XP-2*u0*zM(1)))/XM;
PM(1)=UC*(exp(XP-2*u0*zM(1)))/XM;

XP=-uM(1)*zR+zM(1)*(uM(1)-u0);
BM(1)=(bc0/bcM(1))*UB*exp(XP);
DM(1)=UD*(-exp(XP));
QM(1)=UD*exp(XP);

if M>1
    AXP=zM(1)*(u0-uM(1));
    BXP=zM(1)*(uM(1)-u0);
    for i=2:M
        UA=UA*(ZM(i)-vM(i))/(ZM(i)-vM(i-1));
        AXP=AXP+zM(i)*(uM(i-1)-uM(i));
        AM(i)=(bc0/bcM(i))*UA*(exp(uM(i)*zR+AXP-2*u0*zM(1)))/RM;
        UB=UB*(ZM(i)+vM(i))/(ZM(i)+vM(i-1));
        BXP=BXP+zM(i)*(uM(i)-uM(i-1));
        BM(i)=(bc0/bcM(i))*UB*exp(BXP-uM(i)*zR);
                
        UC=UC*(YM(i)-gamaM(i))/(YM(i)-gamaM(i-1));
        CM(i)=UC*(-exp(uM(i)*zR+AXP-2*u0*zM(1)))/XM;
        PM(i)=UC*(exp(uM(i)*zR+AXP-2*u0*zM(1)))/XM;
        UD=UD*(YM(i)+gamaM(i))/(YM(i)+gamaM(i-1));
        DM(i)=UD*(-exp(BXP-uM(i)*zR));
        QM(i)=UD*exp(BXP-uM(i)*zR);
    end
end

%preparation for output
C0MM=[A0M,B0M,C0M,D0M,P0M,Q0M,u0,v0,gama0,bc0,w];
C0NN=[A0N,B0N,C0N,D0N,P0N,Q0N,u0,v0,gama0,bc0,w];
for m=1:M
    CMM(m,1:11)=[AM(m),BM(m),CM(m),DM(m),PM(m),QM(m),uM(m),vM(m),gamaM(m),bcM(m),w];
end
end
