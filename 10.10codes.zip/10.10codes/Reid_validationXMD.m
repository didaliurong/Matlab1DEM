%model description 
bc=[1d-12,          0.1         1d-12]; %conductivity of each layers(from top to deepest);
h=[1d60,           1            1d60]; %thickness of each layer
z=[           0          1          ]; %interface
%design the Tx-Rx
TX=[0,0,-30];                                                %position of the transmitter
T0=1;                                                        % the transmitter is the 1th layer(air layer)
[Tmodel0,TmodelM,TmodelN]=select_model(T0,bc,h,z);% Rearrange the order of layers 
ff=10.^(1:0.2:5);     %frequencies of the transmitter

%positions of the receivers
%center of discrete cells in the thin sheet
xxP=-804:8:804;
yyP=-804:8:804;
zzP=0.5;  

P=length(xxP)*length(yyP)*length(zzP);
PS=zeros(P,3);

for i=1:length(xxP)
  for j=1:length(yyP)
      for k=1:length(zzP)
        m=(i-1)*length(yyP)*length(zzP)+(j-1)*length(zzP)+k;
        PS(m,1)=xxP(i);
        PS(m,2)=yyP(j);
        PS(m,3)=zzP(k);
      end
  end
end

HZanalysis=zeros(length(ff),1);
HZnumerical=zeros(length(ff),1);
SHZ_INPHASE=zeros(length(ff),1);
SHZ_OUTPHASE=zeros(length(ff),1);
for ii=1:length(ff)
    %fields by numerical integration
    f=ff(ii);
    [ XEx,XEy,XEz ]=E_XMD(PS,TX,Tmodel0,TmodelM,TmodelN,f); %return the electric fields at the center of cells    
    RC=[8,0,-30]; %the position of the receiver for the AEM survey system
    AHZ=wholeHX(RC,PS,f,bc(1));%return the x_directed magnetic field by unit vector electric dipole in whole space 
    SHZ=0;    
    for i=1:P
        SHZ=SHZ+AHZ(1,(i-1)*3+1)*XEx(i)+AHZ(1,(i-1)*3+2)*XEy(i)+AHZ(1,(i-1)*3+3)*XEz(i);%integrate the x-directed magnetic fields by vector electric fields
    end
    HZnumerical(ii)=(bc(2)-bc(1))*64*SHZ;% Multiply the momment of dipole
    %fields by analytical 
    [PZHx11,PZHy,PZHz]=H_XMD(RC,TX,Tmodel0,TmodelM,TmodelN,f);  %return the magnetic fields by x-directed unit magnetic dipole on the 3 layer model analyticallly
    PZHz0=XH_whole(RC,TX,f,bc(1)); %return the magnetic fields by x-directed unit magnetic dipole on the 2 layer model analyticallly
    PZHz=PZHx11-PZHz0;   %get x-directed magnetic fields by the thin sheet analytically  
    HZanalysis(ii)=PZHz;
end

%output results 
filename2=strcat('Reid validation��XMD��curves.txt');
fid2=fopen(filename2,'wt');
for ii=1:length(ff)
    fprintf(fid2,'%12.5g\t',ff(ii));
    fprintf(fid2,'%12.5g\t',real(HZanalysis(ii)));
    fprintf(fid2,'%12.5g\t',imag(HZanalysis(ii)));
    fprintf(fid2,'%12.5g\t',real(HZnumerical(ii)));
    fprintf(fid2,'%12.5g\n',imag(HZnumerical(ii)));
end






