
function T = E_qweXED(rtol,atol,nIntervalsMax,intervals,nQuad,lambda,BJ0,BJ1,R,dx,dy,zR,zT,model0,modelM,modelN,w)
%adapted from Key 2012                  
 
    nDelay = 1;  % must be >= 1, but 1 is usually sufficient.   
    prev = 0;
    for i = 1:nDelay         
        Bindex = (i-1)*nQuad +(1:nQuad);
        EyK  = zeros(length(Bindex),6);
        for j = 1:length(Bindex)
           [C0M,C0N,CM,CN] = CAL_EDabcdpq(lambda(Bindex(j)),model0,modelM,modelN,zR,zT,w);           
           EyK(j,1:6) = getCSEM1DKernelsVX(lambda(Bindex(j)),R,modelM,modelN,dx,dy,zR,zT,C0M,C0N,CM,CN);                   
        end
        bma=(intervals(i+1)-intervals(i))/2;
        EyKernels=[0,0,0];
        EyKernels(1)=bma*(EyK(:,1).'*BJ0(Bindex)) +  bma*(EyK(:,2).'*BJ1(Bindex));
        EyKernels(2)=bma*(EyK(:,3).'*BJ0(Bindex)) +  bma*(EyK(:,4).'*BJ1(Bindex)); 
        EyKernels(3)=bma*(EyK(:,5).'*BJ0(Bindex)) +  bma*(EyK(:,6).'*BJ1(Bindex));  
        prev    = prev + EyKernels; % Call to func returns quadrature sum
    end
% Initialize the T structure for the extrapolation results:
    nKernels = length(prev);  % func from nDelay loop above returns nKernels results    
    nTerms   = nIntervalsMax-nDelay-1;  % maximum number of terms in extrapolation    
    rmin     = realmin;
        
    for i = 1:nKernels  % Preallocating arrays at maximum size for speed
        T(i).S      = zeros(nTerms,1); % working array used for the recursion coefficients for the Epsilon algorithm
        T(i).extrap = zeros(nTerms,1); % extrapolated result for each order of the expansion
        T(i).relErr = zeros(nTerms,1); % relative error for each order 
        T(i).absErr = zeros(nTerms,1); % absolute error for each order    
        converged   = false(nKernels,1);   
    end
    
% The extrapolation transformation loop*********  
    for i = nDelay+1:nTerms
        % Step 1: Compute Guass quadrature of this interval:   
        Bindex = (i-1)*nQuad +(1:nQuad);
        EyK  = zeros(length(Bindex),6);
        for j = 1:length(Bindex)           
           [C0M,C0N,CM,CN] = CAL_EDabcdpq(lambda(Bindex(j)),model0,modelM,modelN,zR,zT,w);        
           EyK(j,1:6) = getCSEM1DKernelsVX(lambda(Bindex(j)),R,modelM,modelN,dx,dy,zR,zT,C0M,C0N,CM,CN);                     
        end
        bma=(intervals(i+1)-intervals(i))/2;
        f=[0,0,0];  
        f(1)=bma*(EyK(:,1).'*BJ0(Bindex)) +  bma*(EyK(:,2).'*BJ1(Bindex)); 
        f(2)=bma*(EyK(:,3).'*BJ0(Bindex)) +  bma*(EyK(:,4).'*BJ1(Bindex));
        f(3)=bma*(EyK(:,5).'*BJ0(Bindex)) +  bma*(EyK(:,6).'*BJ1(Bindex));                
        % Step 2: Compute Shanks transformation for each kernel function:
        for j = 1:nKernels
            
            if  converged(j)  % skip this kernel since its done 
                continue;
            end
            % Insert components into the T structure:
            n           = i-nDelay;
            T(j).n      = n;               % order of the expansion  
            T(j).S(n+1) = T(j).S(n)+f(j);  % working array for transformation
            % Compute the Shanks transform using the Epsilon algorithm:
            % Structured after Weniger (1989, p26)
            aux2 = 0;
            for k = n+1:-1:2
                aux1 = aux2;
                aux2 = T(j).S(k-1);
                ddff = T(j).S(k) - aux2;
                if abs(ddff) < rmin||ddff==0  
                    T(j).S(k-1) = 0;
                else
                    T(j).S(k-1) = aux1 + 1/ddff;
                end
            end
            % The extrapolated result plus the prev integration term:
            T(j).extrap(n) = T(j).S(mod(n,2)+1)+prev(j); 
            % Step 3: Analyze for convergence:
            if n > 1
                T(j).absErr(n) = abs( T(j).extrap(n) - T(j).extrap(n-1));
                T(j).relErr(n) = T(j).absErr(n) / abs(T(j).extrap(n)) ;  
                if T(j).extrap(n)==0  
                   converged(j)=1;    
                else                  
                converged(j)   = T(j).relErr(n) < rtol + atol/abs(T(j).extrap(n));
                end
            end            
        end % loop over nKernels
        
        if all(converged) 
            break; 
        end
        
    end % end extrapolation loop*********
    
    % Clean up the T structure arrays:
    for j = 1:nKernels  
        n = T(j).n;
        T(j).extrap = T(j).extrap(1:n);  
        T(j).relErr = T(j).relErr(1:n); 
        T(j).absErr = T(j).absErr(1:n);  
    end
end 


function EyKernels = getCSEM1DKernelsVX(L,R,modelM,modelN,dx,dy,zR,zT,C0M,C0N,CM,CN)
%return the explicit expressions of EM field derived from the vector potential by J0, J1 order
%find the receiver's layer order*****************
if length(CM)==1%for source in the bottom layer
    if zR<=modelN(1,3)
        pL = max(find(modelN(:,3) > zR)); 
        A=CN(pL,1);B=CN(pL,2);C=CN(pL,3);D=CN(pL,4);P=CN(pL,5);Q=CN(pL,6);u=CN(pL,7);bc=CN(pL,10);w=CN(pL,11);
    else if zR<=zT
            A=C0N(1);B=C0N(2);C=C0N(3);D=C0N(4);P=C0N(5);Q=C0N(6);u=C0N(7);bc=C0N(10);w=C0N(11);
        else
            A=C0M(1);B=C0M(2);C=C0M(3);D=C0M(4);P=C0M(5);Q=C0M(6);u=C0M(7);bc=C0M(10);w=C0M(11);
        end
    end
end

if length(CN)==1%for source in the topmost layer
    if zR>modelM(1,3)
        pL = max(find(modelM(:,3) <= zR));  
        A=CM(pL,1);B=CM(pL,2);C=CM(pL,3);D=CM(pL,4);P=CM(pL,5);Q=CM(pL,6);u=CM(pL,7);bc=CM(pL,10);w=CM(pL,11);
    else if zR<=zT
            A=C0N(1);B=C0N(2);C=C0N(3);D=C0N(4);P=C0N(5);Q=C0N(6);u=C0N(7);bc=C0N(10);w=C0N(11);
        else
            A=C0M(1);B=C0M(2);C=C0M(3);D=C0M(4);P=C0M(5);Q=C0M(6);u=C0M(7);bc=C0M(10);w=C0M(11);
        end
    end
end

if    length(CN)~=1 &&length(CM)~=1%for source in the middle layer
    if zR<=modelN(1,3)
        pL = max(find(modelN(:,3) > zR)); 
        A=CN(pL,1);B=CN(pL,2);C=CN(pL,3);D=CN(pL,4);P=CN(pL,5);Q=CN(pL,6); u=CN(pL,7);bc=CN(pL,10);w=CN(pL,11);
    else if zR>modelM(1,3)
            pL = max(find(modelM(:,3) <= zR));  
            A=CM(pL,1);B=CM(pL,2);C=CM(pL,3);D=CM(pL,4);P=CM(pL,5);Q=CM(pL,6);u=CM(pL,7);bc=CM(pL,10);w=CM(pL,11);
        else if zR<=zT
                A=C0N(1);B=C0N(2);C=C0N(3);D=C0N(4);P=C0N(5);Q=C0N(6);u=C0N(7);bc=C0N(10);w=C0N(11);
            else
                A=C0M(1);B=C0M(2);C=C0M(3);D=C0M(4);P=C0M(5);Q=C0M(6);u=C0M(7);bc=C0M(10);w=C0M(11);
            end
        end
    end
end%end find***************

%coefficents from differential of vector potential 
u0=C0M(7);
A=(L/u0)*A;B=(L/u0)*B;C=(1/L)*C;D=(1/L)*D;P=(L/u0)*P;Q=(L/u0)*Q;
J=sqrt(-1);
mu=4*pi*1e-7;
P0XY=dx*dy/(4*pi*R^2);
P1XY=2*dx*dy/(4*pi*R^3); 
P0XX=dx^2/(4*pi*R^2);
P1XX=(2*dx^2-R^2)/(4*pi*R^3); 
%vector potentials 
A11J0=1/(4*pi)*(A+B); 
A11J1=0;
A21J0=0; 
A21J1=0;
A31J0=0;
A31J1=dx/(4*pi*R)*(-L*(C+D-(u/L^2)*A+(u/L^2)*B));
%differential of vector potential 
V11J0=-P0XX*(L^2*(A+B))-P0XX*(L^2*u*(C-D-(u/L^2)*A-(u/L^2)*B));
V11J1=P1XX*(L*(A+B))+P1XX*(L*u*(C-D-(u/L^2)*A-(u/L^2)*B));
V21J0=-P0XY*(L^2*(A+B))-P0XY*(L^2*u*(C-D-(u/L^2)*A-(u/L^2)*B));
V21J1=P1XY*(L*(A+B))+P1XY*(L*u*(C-D-(u/L^2)*A-(u/L^2)*B));
V31J0=0;
V31J1=dx/(4*pi*R)*(-L*u*(A-B))+dx/(4*pi*R)*(-L*u^2*(C+D-(u/L^2)*A+(u/L^2)*B));

%fields derived from potentials 
%x-directed electric fields by x-directed electric dipole
EXxJ0=-J*w*mu*A11J0+1/bc*V11J0;
EXxJ1=-J*w*mu*A11J1+1/bc*V11J1;
%y-directed electric fields by x-directed electric dipole
EXyJ0=-J*w*mu*A21J0+1/bc*V21J0;
EXyJ1=-J*w*mu*A21J1+1/bc*V21J1;
%z-directed electric fields by x-directed electric dipole
EXzJ0=-J*w*mu*A31J0+1/bc*V31J0;
EXzJ1=-J*w*mu*A31J1+1/bc*V31J1;

EyKernels=[EXxJ0 EXxJ1 EXyJ0 EXyJ1 EXzJ0 EXzJ1];
end
