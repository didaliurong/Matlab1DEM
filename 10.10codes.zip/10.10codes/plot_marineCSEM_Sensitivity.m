
%%%%plan view
EP1HZ=importdata('1Hzmarine sensitivity plane view.txt');
xxP=(-4200:400:8200)/1000;
yyP=(200:400:3000)/1000;
SEX_AMP=EP1HZ(:,3);
SEX_PHASE=EP1HZ(:,4);

ExP_amp=zeros(length(yyP),length(xxP));
ExP_phase=zeros(length(yyP),length(xxP));

for i=1:length(xxP)
for j=1:length(yyP)    
    k=(i-1)*length(yyP)+j;    
    ExP_amp(j,i)=SEX_AMP(k);  
    ExP_phase(j,i)=SEX_PHASE(k);          
end
end


%%%%section view
ED1HZ=importdata('1Hzmarine sensitivity section view.txt');
xxD=(-4200:400:8200)/1000;
zzD=(1100.1:200:4100.1)/1000;
SEX_AMP=ED1HZ(:,3);
SEX_PHASE=ED1HZ(:,4);

ExD_amp=zeros(length(zzD),length(xxD));
ExD_phase=zeros(length(zzD),length(xxD));

for i=1:length(xxD)
for j=1:length(zzD)    
    k=(i-1)*length(zzD)+j;
    
    ExD_amp(j,i)=SEX_AMP(k);  
    ExD_phase(j,i)=SEX_PHASE(k);          
end
end


%%
figure;
subplot(2,2,1)
contour(xxP,yyP,ExP_amp,20);
colormap(jet);
%colorbar
%caxis([0.99,1.1])
k=caxis;
axis ([-4,8,0.2,3]);
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
set(gca,'YTick',1:1:3);
%xlabel('X(m)','FontName','Times New Roman','FontSize',20)
ylabel('Y(km)','FontName','Times New Roman','FontSize',28)
title('Amplitude ratios','FontSize',28)

% Plot the relative error as a function of quadrature order:
subplot(2,2,3)
contour(xxD,zzD,ExD_amp,20); 
caxis(k)
colorbar
axis ([-4,8,1.1,4]);
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('X(km)','FontName','Times New Roman','FontSize',28)
set(gca,'XTick',-4:2:8);
ylabel('Z(km)','FontName','Times New Roman','FontSize',28)
set(gca,'YTick',2:1:4);

subplot(2,2,2)
contour(xxP,yyP,ExP_phase,20);
colormap(jet);
%caxis([0.5,4])
k1=caxis;
axis ([-4,8,0.2,3]);
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
set(gca,'YTick',1:1:3);
%xlabel('X(m)','FontName','Times New Roman','FontSize',20)
%ylabel('Y(m)','FontName','Times New Roman','FontSize',20)
title('Phase difference','FontSize',28)

% Plot the relative error as a function of quadrature order:
subplot(2,2,4)
contour(xxD,zzD,ExD_phase,20); 
caxis(k1)
colorbar
h=colorbar;
set(get(h,'title'),'string','degree');
axis ([-4,8,1.1,4]);
set(gca,'yticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('X(km)','FontName','Times New Roman','FontSize',28)
set(gca,'XTick',-4:2:8);
%ylabel('Z(m)','FontName','Times New Roman','FontSize',20)
set(gca,'YTick',2:1:4);

