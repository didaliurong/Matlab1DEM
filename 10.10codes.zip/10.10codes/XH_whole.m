%return x_directed magnetic field by x_directed unit magnetic dipole in whole space 
function WX= XH_whole( PS,TX,f,bc)
%the expression is according to Ward, S. H. and Hohmann, G. W., 1987.
WX=zeros(size(PS,1),1);
J=sqrt(-1);
k=sqrt(J*2*pi*f*4*pi*1d-7*bc);

 for i=1:size(PS,1)
 dx=PS(i,1)-TX(1);
 dy=PS(i,2)-TX(2); 
 dz=PS(i,3)-TX(3);
 R=sqrt(dx^2+dy^2+dz^2);
    
     WX(i,1)=exp(-J*k*R)/(4*pi*R^3)*((dx*dx/R^2)*(-k^2*R^2+3*J*k*R+3)+(k^2*R^2-J*k*R-1));
 end          
end

