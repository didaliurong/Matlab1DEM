%%%%section view of backgroud model 
EB1HZ=importdata('1Hzmarine 1D electric vector in background model.txt');
xxB=(-8200:400:8200)/1000;
zzB=(0.1:200:4000.1)/1000;
J=sqrt(-1);
XEx=EB1HZ(:,3)+J*EB1HZ(:,4);
XEz=EB1HZ(:,5)+J*EB1HZ(:,6);

ExB_inphase=zeros(length(zzB),length(xxB));
ExB_outphase=zeros(length(zzB),length(xxB));
EzB_inphase=zeros(length(zzB),length(xxB));
EzB_outphase=zeros(length(zzB),length(xxB));
ESB_inphase=zeros(length(zzB),length(xxB));
ESB_outphase=zeros(length(zzB),length(xxB));
for i=1:length(xxB)
for j=1:length(zzB)    
    k=(i-1)*length(zzB)+j;
    if zzB(j)<1000
    ExB_inphase(j,i)=3.3*real(XEx(k));  
    ExB_outphase(j,i)=3.3*imag(XEx(k));
    EzB_inphase(j,i)=3.3*real(XEz(k));  
    EzB_outphase(j,i)=3.3*imag(XEz(k));
    ESB_inphase(j,i)=log10(3.3*(sqrt(real(XEx(k))^2+real(XEz(k))^2)));  
    ESB_outphase(j,i)=log10(3.3*(sqrt(imag(XEx(k))^2+imag(XEz(k))^2)));
    
        else
    ExB_inphase(j,i)=real(XEx(k));  
    ExB_outphase(j,i)=imag(XEx(k));
    EzB_inphase(j,i)=real(XEz(k));  
    EzB_outphase(j,i)=imag(XEz(k));      
    ESB_inphase(j,i)=log10(sqrt(real(XEx(k))^2+real(XEz(k))^2));  
    ESB_outphase(j,i)=log10(sqrt(imag(XEx(k))^2+imag(XEz(k))^2));        
    end    
end
end


%%%%section view of 1D reservior model 
EB1HZ=importdata('1Hzmarine 1D electric vector in reservior model.txt');
xx=(-8200:400:8200)/1000;
zz=(0.1:200:4000.1)/1000;
J=sqrt(-1);
XEx=EB1HZ(:,3)+J*EB1HZ(:,4);
XEz=EB1HZ(:,5)+J*EB1HZ(:,6);

Ex_inphase=zeros(length(zz),length(xx));
Ex_outphase=zeros(length(zz),length(xx));
Ez_inphase=zeros(length(zz),length(xx));
Ez_outphase=zeros(length(zz),length(xx));
ES_inphase=zeros(length(zz),length(xx));
ES_outphase=zeros(length(zz),length(xx));
for i=1:length(xx)
for j=1:length(zz)    
    k=(i-1)*length(zz)+j;
    if zz(j)<1
    Ex_inphase(j,i)=3.3*real(XEx(k));  
    Ex_outphase(j,i)=3.3*imag(XEx(k));
    Ez_inphase(j,i)=3.3*real(XEz(k));  
    Ez_outphase(j,i)=3.3*imag(XEz(k));
    ES_inphase(j,i)=log10(3.3*(sqrt(real(XEx(k))^2+real(XEz(k))^2)));  
    ES_outphase(j,i)=log10(3.3*(sqrt(imag(XEx(k))^2+imag(XEz(k))^2)));
    else if 2<zz(j)<2.1
    Ex_inphase(j,i)=0.01*real(XEx(k));  
    Ex_outphase(j,i)=0.01*imag(XEx(k));
    Ez_inphase(j,i)=0.01*real(XEz(k));  
    Ez_outphase(j,i)=0.01*imag(XEz(k));
    ES_inphase(j,i)=log10(0.01*(sqrt(real(XEx(k))^2+real(XEz(k))^2)));  
    ES_outphase(j,i)=log10(0.01*(sqrt(imag(XEx(k))^2+imag(XEz(k))^2))); 
        else
    Ex_inphase(j,i)=real(XEx(k));  
    Ex_outphase(j,i)=imag(XEx(k));
    Ez_inphase(j,i)=real(XEz(k));  
    Ez_outphase(j,i)=imag(XEz(k));      
    ES_inphase(j,i)=log10(sqrt(real(XEx(k))^2+real(XEz(k))^2));  
    ES_outphase(j,i)=log10(sqrt(imag(XEx(k))^2+imag(XEz(k))^2));        
        end
    end
end
end

%%
figure;
subplot(2,2,1)
contour(xxB,zzB,ESB_inphase,500);
colormap(jet);
caxis([-18,-9])
k=caxis;
axis ([-8,8,0,4]);
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
%xlabel('X(m)','FontName','Times New Roman','FontSize',20)
ylabel('Z(km)','FontName','Times New Roman','FontSize',28)
title('Inphase currents','FontSize',28)
hold on 
h=quiver (xxB,zzB,ExB_inphase./sqrt(ExB_inphase.^2+EzB_inphase.^2),EzB_inphase./sqrt(ExB_inphase.^2+EzB_inphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[1,1],'w-','Linewidth',2)
hold off

subplot(2,2,2)
contour(xxB,zzB,ESB_outphase,500); 
caxis(k)
axis ([-8,8,0,4]);
set(gca,'xticklabel',[])
set(gca,'yticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
%xlabel('X(m)','FontName','Times New Roman','FontSize',20)
%ylabel('Z(m)','FontName','Times New Roman','FontSize',20)
title('Quadrature currents','FontSize',28)
hold on 
h=quiver (xxB,zzB,ExB_outphase./sqrt(ExB_outphase.^2+EzB_outphase.^2),EzB_outphase./sqrt(ExB_outphase.^2+EzB_outphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[1,1],'w-','Linewidth',2)
hold off

subplot(2,2,3)
contour(xx,zz,ES_inphase,500);
caxis(k)
axis ([-8,8,0,4]);
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('X(km)','FontName','Times New Roman','FontSize',28)
set(gca,'XTick',-8:2:8);
ylabel('Z(km)','FontName','Times New Roman','FontSize',28)
hold on 
h=quiver (xx,zz,Ex_inphase./sqrt(Ex_inphase.^2+Ez_inphase.^2),Ez_inphase./sqrt(Ex_inphase.^2+Ez_inphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[1,1],'w-','Linewidth',2)
plot([8,-8],[2,2],'w-','Linewidth',2)
plot([8,-8],[2.1,2.1],'w-','Linewidth',2)
hold off

subplot(2,2,4)
contour(xx,zz,ES_outphase,500); 
caxis(k)
colorbar
h=colorbar;
set(get(h,'title'),'string','log10(A)');
axis ([-8,8,0,4]);
set(gca,'yticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
xlabel('X(km)','FontName','Times New Roman','FontSize',28)
set(gca,'XTick',-8:2:8);
%ylabel('Z(m)','FontName','Times New Roman','FontSize',20)
hold on 
h=quiver (xx,zz,Ex_outphase./sqrt(Ex_outphase.^2+Ez_outphase.^2),Ez_outphase./sqrt(Ex_outphase.^2+Ez_outphase.^2),'k');
set(h,'MaxHeadSize',0.2,'AutoScaleFactor',0.5)
plot([8,-8],[1,1],'w-','Linewidth',2)
plot([8,-8],[2,2],'w-','Linewidth',2)
plot([8,-8],[2.1,2.1],'w-','Linewidth',2)
hold off
