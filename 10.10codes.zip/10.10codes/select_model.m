function [ Tmodel0,TmodelM,TmodelN ] = select_model(T0,bc,h,z)

%parameters in the source layer
Tbc0=bc(T0);Th0=h(T0); 
Tmodel0=[Tbc0,Th0];

%parameters beneath the source layer
TM=length(bc)-T0; 
if TM==0
   TmodelM=0;
else
TbcM=bc(T0+1:length(bc)); 
ThM=h(T0+1:length(bc));  
TzM=z(T0:length(z)); 
TmodelM=zeros(TM,3);
 for m=1:TM
 TmodelM(m,:)=[TbcM(m),ThM(m),TzM(m)];
 end
end

%parameters above the source layer
TN=T0-1; 
if TN==0
  TmodelN=0;
else
TbcN=bc(T0-1:-1:1); 
ThN=h(T0-1:-1:1);   
TzN=z(T0-1:-1:1);   
TmodelN=zeros(TN,3);
 for n=1:TN
 TmodelN(n,:)=[TbcN(n),ThN(n),TzN(n)];
 end
end

end

