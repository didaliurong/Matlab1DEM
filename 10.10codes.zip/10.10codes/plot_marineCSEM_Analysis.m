RX=100:200:8100;
J=sqrt(-1);
%
E1HZ=importdata('1Hzmarine 1D analysis solution.txt');

Ex_up2=E1HZ(:,2)+J*E1HZ(:,3);
Ex_up1=E1HZ(:,4)+J*E1HZ(:,5);
Ex_down2=E1HZ(:,6)+J*E1HZ(:,7);
Ex_down1=E1HZ(:,8)+J*E1HZ(:,9);

Ez_up2=E1HZ(:,10)+J*E1HZ(:,11);
Ez_up1=E1HZ(:,12)+J*E1HZ(:,13);
Ez_down2=E1HZ(:,14)+J*E1HZ(:,15);
Ez_down1=E1HZ(:,16)+J*E1HZ(:,17);
%%
figure;
subplot(2,2,1)
plot(RX,log10(abs(Ex_up2)),'r-o',...
     RX,log10(abs(Ex_down2)),'r:x',...
     RX,log10(abs(Ex_up1)),'b-o',...
     RX,log10(abs(Ex_down1)),'b:x','Linewidth',1)
%xlabel('Range (m)','FontName','Times New Roman','FontSize',20)
ylabel('log10[Amplitude (A/m)]','FontName','Times New Roman','FontSize',28)
axis ([50,8000,-21,-8])
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
%set(gca,'ytick',10.^[-30:2:0])
h1=legend('above','beneath','above','beneath');
set(h1,'FontName','Times New Roman','FontSize',28)
title('Ex','FontSize',28)

subplot(2,2,2)
plot(RX,log10(abs(Ez_up2)),'r-o',...
     RX,log10(abs(Ez_down2)),'r:x',...
     RX,log10(abs(Ez_up1)),'b-o',...
     RX,log10(abs(Ez_down1)),'b:x','Linewidth',1)
%xlabel('Range (m)','FontName','Times New Roman','FontSize',20)
%ylabel('Phase(degree)','FontName','Times New Roman','FontSize',20)
axis ([50,8000,-19,-8])
set(gca,'xticklabel',[])
set(gca,'FontName','Times New Roman','FontSize',28)
%set(gca,'ytick',10.^[-30:2:0])
h1=legend(' +*Ez','  -*Ez','+&Ez',' -&Ez');
set(h1,'FontName','Times New Roman','FontSize',28)
title('Ez','FontSize',28)

subplot(2,2,3)
plot(RX,180/pi*phase(Ex_up2),'r-o',...
    RX,180/pi*phase(Ex_down2),'r:x',...
    RX,180/pi*phase(Ex_up1),'b-o',...
    RX,180/pi*phase(Ex_down1),'b:x','Linewidth',1);  

xlabel('X(m)','FontName','Times New Roman','FontSize',28)
ylabel('Phase(degree)','FontName','Times New Roman','FontSize',28)
axis ([50,8000,-400,0])
set(gca,'FontName','Times New Roman','FontSize',28)
h1=legend(' +*Ex','  -*Ex','+&Ex',' -&Ex');
set(h1,'FontName','Times New Roman','FontSize',28)
 
subplot(2,2,4)
plot(RX,180/pi*phase(Ez_up2),'r-o',...
     RX,180/pi*phase(Ez_down2),'r:x',...
     RX,180/pi*phase(Ez_up1),'b-o',...
     RX,180/pi*phase(Ez_down1),'b:x','Linewidth',1);  

xlabel('X(m)','FontName','Times New Roman','FontSize',28)
%ylabel('Ez-Phase(degree)','FontName','Times New Roman','FontSize',20)
axis ([50,8000,-400,50])
set(gca,'FontName','Times New Roman','FontSize',28)
h1=legend(' +*Ez','  -*Ez','+&Ez',' -&Ez');
set(h1,'FontName','Times New Roman','FontSize',28)
 